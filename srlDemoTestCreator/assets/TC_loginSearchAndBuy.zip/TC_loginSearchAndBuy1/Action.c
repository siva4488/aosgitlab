//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("navigate");
	truclient_step("1", "Navigate to 'http://AOS-Site'", "snapshot=Action_1.inf");
	lr_end_transaction("navigate",0);
	lr_start_transaction("Login");
	truclient_step("2", "Click on element (1)", "snapshot=Action_2.inf");
	truclient_step("3", "Click on Username label", "snapshot=Action_3.inf");
	truclient_step("4", "Evaluate JavaScript code var uandp = TC.getParam(...ser + ' ' + pw);", "snapshot=Action_4.inf");
	truclient_step("5", "Type user in Username textbox", "snapshot=Action_5.inf");
	truclient_step("6", "Click on Password label", "snapshot=Action_6.inf");
	truclient_step("7", "Type ** in Password passwordbox", "snapshot=Action_7.inf");
	truclient_step("8", "Click on SIGN IN", "snapshot=Action_8.inf");
	lr_end_transaction("Login",0);
	lr_start_transaction("select product and add to cart");
	truclient_step("12", "Click on LAPTOPS Shop Now", "snapshot=Action_12.inf");
	truclient_step("13", "Click on image (1) image", "snapshot=Action_13.inf");
	truclient_step("14", "Click on Plus", "snapshot=Action_14.inf");
	truclient_step("15", "Click on ADD TO CART button", "snapshot=Action_15.inf");
	lr_end_transaction("select product and add to cart",0);
	lr_start_transaction("checkout and buy");
	truclient_step("16", "Click on CHECKOUT ($2,523.98) button", "snapshot=Action_16.inf");
	truclient_step("17", "Click on NEXT button", "snapshot=Action_17.inf");
	truclient_step("18", "Click on SafePay username label", "snapshot=Action_18.inf");
	truclient_step("19", "Type Eva1234 in *SafePay username textbox", "snapshot=Action_19.inf");
	truclient_step("20", "Type ******** in *SafePay password passwordbox", "snapshot=Action_20.inf");
	truclient_step("21", "Click on PAY NOW label", "snapshot=Action_21.inf");
	lr_end_transaction("checkout and buy",0);
	truclient_step("22", "Verify Thank you for buying... 's 'Visible Text' Contain Thank you for buying with Advantage", "snapshot=Action_22.inf");

	return 0;
}
